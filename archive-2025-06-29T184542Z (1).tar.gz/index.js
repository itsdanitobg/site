const express = require('express');
const path = require('path');
const app = express();
const port = 2002;
app.use(express.static('public'));
const webhookUrl = 'https://discord.com/api/webhooks/1343205173576859731/vp8yEMngfG2GYJwmTriXDspK0z0xrqa7RXJPXKiHg2fddjvcn7blkSLVBlFQgSiXdK1t';
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'scripts', 'itsdanitobg.html'));
});
app.get('/script', (req, res) => {
    res.sendFile(path.join(__dirname, 'scripts', 'script.txt'));
});
app.get('/verify', (req, res) => {
    res.sendFile(path.join(__dirname, 'scripts', 'verify.txt'));
});
app.get('/crash', (req, res) => {
    res.sendFile(path.join(__dirname, 'scripts', 'crash.txt'));
});
app.get('/dimens', (req, res) => {
    res.sendFile(path.join(__dirname, 'scripts', 'main.html'));
});
app.get('/contacts', (req, res) => {
    res.sendFile(path.join(__dirname, 'scripts', 'contacts.html'));
});
app.get('/script.js', (req, res) => {
    res.sendFile(path.join(__dirname, 'scripts', 'script.js'));
});
app.get('/styles.css', (req, res) => {
    res.sendFile(path.join(__dirname, 'scripts', 'styles.css'));
});
app.get('/steamtools', (req, res) => {
    res.sendFile(path.join(__dirname, 'scripts', 'steamtools.html'));
});
app.get('/download', (req, res) => {
    res.sendFile(path.join(__dirname, 'scripts', 'download.html'));
});
app.get('/liniq', (req, res) => {
    res.sendFile(path.join(__dirname, 'scripts', 'liniq.html'));
});
app.get('/amugus', (req, res) => {
    res.sendFile(path.join(__dirname, 'scripts', 'amugus.txt'));
});
app.get('/discord', (req, res) => {
    res.sendFile(path.join(__dirname, 'scripts', 'discord.html'));
});
app.get('/games', (req, res) => {
    res.sendFile(path.join(__dirname, 'scripts', 'games.html'));
});
app.get('/services', (req, res) => {
    res.sendFile(path.join(__dirname, 'scripts', 'services.html'));
});
app.get('/about', (req, res) => {
    res.sendFile(path.join(__dirname, 'scripts', 'about.html'));
});
app.get('/uploads', (req, res) => {
    res.sendFile(path.join(__dirname, 'scripts', 'uploads.html'));
});
app.get('/gameids', (req, res) => {
    res.sendFile(path.join(__dirname, 'scripts', 'games.txt'));
});
app.get('/discordui.css', (req, res) => {
    res.sendFile(path.join(__dirname, 'scripts', 'discordui.css'));
});
app.get('/games.txt', (req, res) => {
    res.sendFile(path.join(__dirname, 'scripts', 'games.txt'));
});
app.get('/steam', (req, res) => {
    res.sendFile(path.join(__dirname, 'scripts', 'steam.html'));
});
app.get('/downloads', (req, res) => {
    res.sendFile(path.join(__dirname, 'scripts', 'downloads.html'));
});
app.get('/steam', (req, res) => {
    res.sendFile(path.join(__dirname, 'scripts', 'steam.html'));
});
app.get('/games-manager', (req, res) => {
    res.sendFile(path.join(__dirname, 'updater', 'games-manager.txt'));
});
app.get('/online-fixer', (req, res) => {
    res.sendFile(path.join(__dirname, 'updater', 'online-fixer.txt'));
});


function sendWebhook(branch, endpoint) {
    const content = `Downloaded game id ${encodeURIComponent(branch)} from ${endpoint}`;
    fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content })
    });
}

function makeRoute(endpoint, githubUrl) {
    app.get(`/${endpoint}/:file.zip`, (req, res) => {
        const branch = req.params.file;
        const redirectUrl = `${githubUrl}${encodeURIComponent(branch)}.zip`;
        sendWebhook(branch, endpoint);
        res.redirect(302, redirectUrl);
    });
}

makeRoute('endpoint-1', 'https://github.com/KunalR31/manifest/archive/refs/heads/');
makeRoute('endpoint-2', 'https://github.com/0kingle/SteamViolatorHub/archive/refs/heads/');
makeRoute('endpoint-3', 'https://github.com/Auiowu/ManifestAutoUpdate/archive/refs/heads/');
makeRoute('endpoint-4', 'https://github.com/ManifestHub/ManifestHub/archive/refs/heads/');
makeRoute('endpoint-5', 'https://github.com/tymolu233/ManifestAutoUpdate-fix/archive/refs/heads/');
makeRoute('endpoint-6', 'https://github.com/Fairyvmos/BlankTMing/archive/refs/heads/');
makeRoute('endpoint-7', 'https://github.com/SteamAutoCracks/ManifestHub/archive/refs/heads/');
app.get('/updater.exe', (req, res) => {
    const branch = req.params.file;
    const redirectUrl = `https://raw.githubusercontent.com/itsdanitobg/site/refs/heads/main/Game%20manager.exe`;
    res.redirect(302, redirectUrl);
});
app.use((req, res) => {
    res.status(404).sendFile(path.join(__dirname, 'scripts', '404.html'));
});
app.listen(port, () => {
    console.log(`Listening on port ${port}`);
});