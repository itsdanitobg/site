document.getElementById("showMoreBtn").addEventListener("click", function() {
    const fullDescription = document.getElementById("fullDescription");
    if (fullDescription.style.display === "none") {
        fullDescription.style.display = "block";
        this.textContent = "Вижте по-малко";
    } else {
        fullDescription.style.display = "none";
        this.textContent = "Вижте още";
    }
});
