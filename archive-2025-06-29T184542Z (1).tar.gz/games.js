const fetch = require('node-fetch');
const fs = require('fs-extra');
const path = require('path');

const BASE_URL = 'https://furcate.eu/files/';
const SAVE_DIR = path.join(__dirname, 'games');
const STEAM_API = 'https://store.steampowered.com/api/appdetails?appids=';

let gameId = 5270;

async function isGameFreeOnSteam(appid) {
  try {
    const res = await fetch(`${STEAM_API}${appid}`);
    const data = await res.json();
    if (data[appid]?.success && data[appid].data?.is_free) {
      return true;
    }
  } catch {}
  return false;
}

async function fileExists(url) {
  try {
    const res = await fetch(url, {
      method: 'HEAD',
      headers: {
        'sec-ch-ua': '"Chromium";v="136", "Google Chrome";v="136", "Not.A/Brand";v="99"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'Referer': 'https://furcate.eu/manifest.html',
        'Referrer-Policy': 'strict-origin-when-cross-origin',
      }
    });
    return res.ok;
  } catch {
    return false;
  }
}

async function downloadFile(url, dest) {
  const res = await fetch(url, {
    method: 'GET',
    headers: {
      'sec-ch-ua': '"Chromium";v="136", "Google Chrome";v="136", "Not.A/Brand";v="99"',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-platform': '"Windows"',
      'upgrade-insecure-requests': '1',
      'Referer': 'https://furcate.eu/manifest.html',
      'Referrer-Policy': 'strict-origin-when-cross-origin'
    }
  });

  if (!res.ok) throw new Error(`Download failed: ${res.statusText}`);
  await fs.ensureDir(SAVE_DIR);
  const fileStream = fs.createWriteStream(path.join(SAVE_DIR, `${gameId}.zip`));
  return new Promise((resolve, reject) => {
    res.body.pipe(fileStream);
    res.body.on('error', reject);
    fileStream.on('finish', resolve);
  });
}

async function run() {
  while (true) {
    const url = `${BASE_URL}${gameId}.zip`;

    const exists = await fileExists(url);
    if (!exists) {
      console.log(`[${gameId}] File does not exist. Skipping.`);
      gameId += 10;
      await new Promise(res => setTimeout(res, 1));
      continue;
    }

    const isFree = await isGameFreeOnSteam(gameId);
    if (isFree) {
      console.log(`[${gameId}] Game is free on Steam. Skipping download.`);
      gameId += 10;
      continue;
    }

    try {
      await downloadFile(url);
      console.log(`[${gameId}] Downloaded successfully.`);
    } catch (err) {
      console.error(`[${gameId}] Download failed: ${err.message}`);
    }

    gameId += 10;
    await new Promise(res => setTimeout(res, 1));
  }
}

run();
